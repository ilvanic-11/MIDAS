# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.higher_order_hexahedron import HigherOrderHexahedron


class BezierHexahedron(HigherOrderHexahedron):
    """
    BezierHexahedron - A 3d cell that represents an arbitrary order
    Bezier hex
    
    Superclass: HigherOrderHexahedron
    
    BezierHexahedron is a concrete implementation of Cell to
    represent a 3d hexahedron using Bezier shape functions of user
    specified order.
    
    @sa
    Hexahedron
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkBezierHexahedron, obj, update, **traits)
    
    def _get_rational_weights(self):
        return wrap_vtk(self._vtk_obj.GetRationalWeights())
    rational_weights = traits.Property(_get_rational_weights, desc=\
        """
        
        """
    )

    def evaluate_location_projected_node(self, *args):
        """
        V.evaluate_location_projected_node(int, int, [float, float, float],
            [float, ...])
        C++: void EvaluateLocationProjectedNode(int &subId,
            const IdType point_id, double x[3], double *weights)"""
        ret = self._wrap_call(self._vtk_obj.EvaluateLocationProjectedNode, *args)
        return ret

    def set_rational_weights_from_point_data(self, *args):
        """
        V.set_rational_weights_from_point_data(PointData, int)
        C++: void SetRationalWeightsFromPointData(
            PointData *point_data, const IdType numPts)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetRationalWeightsFromPointData, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('parametric_coords',
    'GetParametricCoords'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'parametric_coords'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(BezierHexahedron, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit BezierHexahedron properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['parametric_coords']),
            title='Edit BezierHexahedron properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit BezierHexahedron properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

