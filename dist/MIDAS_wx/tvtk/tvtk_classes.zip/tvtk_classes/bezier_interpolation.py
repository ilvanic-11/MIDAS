# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.higher_order_interpolation import HigherOrderInterpolation


class BezierInterpolation(HigherOrderInterpolation):
    """
    BezierInterpolation
    
    Superclass: HigherOrderInterpolation
    
    See Also:
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkBezierInterpolation, obj, update, **traits)
    
    def evaluate_shape_and_gradient(self, *args):
        """
        V.evaluate_shape_and_gradient(int, float, [float, ...], [float, ...])
        C++: static void EvaluateShapeAndGradient(int order,
            double pcoord, double *shape, double *grad)"""
        ret = self._wrap_call(self._vtk_obj.EvaluateShapeAndGradient, *args)
        return ret

    def evaluate_shape_functions(self, *args):
        """
        V.evaluate_shape_functions(int, float, [float, ...])
        C++: static void EvaluateShapeFunctions(int order, double pcoord,
            double *shape)"""
        ret = self._wrap_call(self._vtk_obj.EvaluateShapeFunctions, *args)
        return ret

    def tensor1_shape_derivatives(self, *args):
        """
        V.tensor1_shape_derivatives((int), (float, ...), [float, ...])
            -> int
        C++: static int Tensor1ShapeDerivatives(const int order[1],
            const double *pcoords, double *derivs)"""
        ret = self._wrap_call(self._vtk_obj.Tensor1ShapeDerivatives, *args)
        return ret

    def tensor1_shape_functions(self, *args):
        """
        V.tensor1_shape_functions((int), (float, ...), [float, ...]) -> int
        C++: static int Tensor1ShapeFunctions(const int order[1],
            const double *pcoords, double *shape)"""
        ret = self._wrap_call(self._vtk_obj.Tensor1ShapeFunctions, *args)
        return ret

    def tensor2_shape_derivatives(self, *args):
        """
        V.tensor2_shape_derivatives((int, int), (float, ...), [float, ...])
            -> int
        C++: static int Tensor2ShapeDerivatives(const int order[2],
            const double *pcoords, double *derivs)"""
        ret = self._wrap_call(self._vtk_obj.Tensor2ShapeDerivatives, *args)
        return ret

    def tensor2_shape_functions(self, *args):
        """
        V.tensor2_shape_functions((int, int), (float, ...), [float, ...])
            -> int
        C++: static int Tensor2ShapeFunctions(const int order[2],
            const double *pcoords, double *shape)"""
        ret = self._wrap_call(self._vtk_obj.Tensor2ShapeFunctions, *args)
        return ret

    def tensor3_shape_derivatives(self, *args):
        """
        V.tensor3_shape_derivatives((int, int, int), (float, ...), [float,
            ...]) -> int
        C++: static int Tensor3ShapeDerivatives(const int order[3],
            const double *pcoords, double *derivs)"""
        ret = self._wrap_call(self._vtk_obj.Tensor3ShapeDerivatives, *args)
        return ret

    def tensor3_shape_functions(self, *args):
        """
        V.tensor3_shape_functions((int, int, int), (float, ...), [float,
            ...]) -> int
        C++: static int Tensor3ShapeFunctions(const int order[3],
            const double *pcoords, double *shape)"""
        ret = self._wrap_call(self._vtk_obj.Tensor3ShapeFunctions, *args)
        return ret

    def wedge_shape_derivatives(self, *args):
        """
        V.wedge_shape_derivatives((int, int, int), int, (float, ...),
            [float, ...])
        C++: static void WedgeShapeDerivatives(const int order[3],
            const IdType numberOfPoints, const double *pcoords,
            double *derivs)"""
        ret = self._wrap_call(self._vtk_obj.WedgeShapeDerivatives, *args)
        return ret

    def wedge_shape_functions(self, *args):
        """
        V.wedge_shape_functions((int, int, int), int, (float, ...), [float,
            ...])
        C++: static void WedgeShapeFunctions(const int order[3],
            const IdType numberOfPoints, const double *pcoords,
            double *shape)"""
        ret = self._wrap_call(self._vtk_obj.WedgeShapeFunctions, *args)
        return ret

    def de_casteljau_simplex(self, *args):
        """
        V.de_casteljau_simplex(int, int, (float, ...), [float, ...])
        C++: static void deCasteljauSimplex(const int dim, const int deg,
            const double *pcoords, double *weights)"""
        ret = self._wrap_call(self._vtk_obj.deCasteljauSimplex, *args)
        return ret

    def de_casteljau_simplex_deriv(self, *args):
        """
        V.de_casteljau_simplex_deriv(int, int, (float, ...), [float, ...])
        C++: static void deCasteljauSimplexDeriv(const int dim,
            const int deg, const double *pcoords, double *weights)"""
        ret = self._wrap_call(self._vtk_obj.deCasteljauSimplexDeriv, *args)
        return ret

    def flatten_simplex(self, *args):
        """
        V.flatten_simplex(int, int, Vector3i) -> int
        C++: static int flattenSimplex(const int dim, const int deg,
            const Vector3i coord)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.flattenSimplex, *my_args)
        return ret

    def unflatten_simplex(self, *args):
        """
        V.unflatten_simplex(int, int, int) -> Vector3i
        C++: static Vector3i unflattenSimplex(const int dim,
            const int deg, const IdType flat)"""
        ret = self._wrap_call(self._vtk_obj.unflattenSimplex, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(BezierInterpolation, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit BezierInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], []),
            title='Edit BezierInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit BezierInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

